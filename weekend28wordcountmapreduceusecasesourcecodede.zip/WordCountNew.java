import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class WordCountNew {
	
	// Below is the Mapper Class Defination
	public static class TokenizerMapper1 extends Mapper<Object, Text, Text, IntWritable>
	{
		//INPUT DATA  - hadoop is bigdata tool
		// 1111L , hadoop is bigdata tool -----------> hadoop	1
		//                                                              is	1
		//                                                              bigdata	1
		//                                                              tool	1
		// Object , Text -------------------------------> Text , IntWritable
		
		// LOCAL VARIABLES DECLARATION
		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();
		
		// Below method we have to override to write Mapper Business Logic
		public void map(Object key , Text value,Context context) throws IOException, InterruptedException
		{
			// InputData--> 111L , hadoop is bigdata tool
			StringTokenizer itr = new StringTokenizer(value.toString());
			// NULL
			// hadoop
			// is
			//bigdata
			// tool
			while(itr.hasMoreTokens())
			{
				System.out.println("**** IN MAP METHOD *****");
				word.set(itr.nextToken());
				System.out.println("**** WORD IS :" + word);
				context.write(word, one); // hadoop	1   
				                                     //  Text     IntWritable
			}
			
			
		}// End of Map Method
		
		
	} // End of Mapper Class
	// Below code for Reducer Class Developement
	public static class IntSumReducer extends Reducer<Text, IntWritable, Text, IntWritable>
	{
		// Input Data for Reducer--> hadoop ,      1,1,1,1 ----------> hadoop	4
		//                                       Text            IntWritable-------> Text     IntWritable
		//Below Method we have to override to write Reducer Business Logic
		IntWritable result = new IntWritable();
		public void reduce(Text key , Iterable<IntWritable> values,Context context) throws IOException, InterruptedException
		{
			int sum = 0;
			for(IntWritable val:values)
			{
				sum += val.get(); // sum = sum + val.get();
			}
			result.set(sum);
			System.out.println("SUM IS:" + result);
			context.write(key,result);			
		} // End of reduce method
		
	} // End of Reducer Class

	/**
	 * @param args
	 * @throws IOException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("**** IN DRIVER CLASS ****");
		
		// Configuration Details w.r.to JOB, JAR etc
		
		Configuration conf = new Configuration();
		Job job = new Job(conf,"WORDCOUNTJOB");
		job.setJarByClass(WordCountNew.class);
		
		// Mapper , Combiner & Reducer Class Name Details
		
		job.setMapperClass(TokenizerMapper1.class); // Mapper Logic Class Reference
		job.setCombinerClass(IntSumReducer.class);// Combiner is only for better Network Optimization
		job.setReducerClass(IntSumReducer.class);// Reducer Logic Class Reference
		
		// Output KEY,VALUE Datatypes Details
		
		job.setOutputKeyClass(Text.class); // hadoop
		job.setOutputValueClass(IntWritable.class); // 10
		
		// Input & Output Path Details for execution
		
		FileInputFormat.addInputPath(job, new Path(args[0]));//    /MRInput/Input.log
		FileOutputFormat.setOutputPath(job, new Path(args[1])); //    /MROutput
		
		//System Exit Process
		
		System.exit(job.waitForCompletion(true)?0:1);

	}

}














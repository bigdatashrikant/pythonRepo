dirpath=/WD_WebIntel/Analytics/LogAnalysisProcess71
timestamp=$(date +"%Y-%m-%d-%S")
hadoop dfsadmin -safemode leave
hadoop fs -test -d $dirpath
if [ $? != 0 ]
  then 
     hadoop fs -mkdir $dirpath
  else 
     echo "Directory Alredy exists on HDFS"
     exit
fi
cat *.log|wc -l >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fs -put *.log $dirpath >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fs -lsr $dirpath >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fs -cat $dirpath/*|wc -l >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fs -du $dirpath >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fsck -blocks $dirpath >> /home/BATCH69/LOGS/hdfsLog_$timestamp

hadoop fs -count $dirpath >> /home/BATCH69/LOGS/hdfsLog_$timestamp
hadoop fs -stat $dirpath/* >> /home/BATCH69/LOGS/hdfsLog_$timestamp
echo "Data Loading Done on HDFS Sucessfully" >> /home/BATCH67/LOGS/hdfsLog_$timestamp
